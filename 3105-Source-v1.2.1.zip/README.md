# 3105 · 和平精英 Paks 一键导入版

基于 OGIOS/ThreeOneOSFive 源码改造（内核提权 + 容器访问），界面保持原样，首页新增「和平精英 PAKS」面板：

- ① 添加 pak 文件：从「文件」里挑 pak，复制进 App
- ② 一键导入到 Paks：覆盖游戏 Documents/ShadowTrackerExtra/Saved/Paks 里的同名文件
- ③ 一键删除已导入的文件：把导入过的那几个从游戏 Paks 里删掉

构建：.github/workflows/main.yml（unsigned ipa，自行用 ESign/企业证书签名）
