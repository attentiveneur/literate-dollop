//
//  LSPaths.swift
//  v16.2
//
//  这一版不再连 Filza 的网络服务，所以中转站就落在本 App 自己的 Documents 里。
//  Documents 已经在「文件」App → 我的 iPhone → 浪神搬运 里露出来了，
//  微信 / QQ / AirDrop / iCloud 都可以直接把包存进来，不用任何服务器。
//
//  v16.3：按「不保留原文件」来做。包放进「我的包」→ 导入时直接覆盖游戏里那份，
//  覆盖成功之后，App 里这个副本立刻丢掉；移出同理，从游戏里拿出来就地丢掉，
//  既不还原游戏原文件，也不在 App 里留第二份。
//  丢弃全程只用 rename / move（先挪进隐藏回收站 .trash），不对游戏目录调删除接口。
//

import Foundation

enum LSPaths {

    static let pakExts: Set<String> = ["pak", "sig", "uasset", "ucas", "utoc"]

    // MARK: - 自己的目录

    static func docDir() -> URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    /// ① 我的包（常驻库）：包放进来一次就留在这，导入后也不搬走
    static func inboxDir() -> URL {
        docDir().appendingPathComponent("待导入", isDirectory: true)
    }

    /// ② 已导入：老版本的存放点。v16.2 起不再往这放；
    ///    升级时会把这里已有的包搬回常驻库，免得你还得重放一遍
    static func sentDir() -> URL {
        docDir().appendingPathComponent("已导入", isDirectory: true)
    }

    /// ③ 已移出：从游戏里搬出来的包落这里
    static func outDir() -> URL {
        docDir().appendingPathComponent("已移出", isDirectory: true)
    }

    /// 万一跨卷搬不动，把挪不走的旧文件收进这里（点开头，界面和文件 App 都不显示）
    static func retiredDir() -> URL {
        docDir().appendingPathComponent(".retired", isDirectory: true)
    }

    /// 一次性回收站：v16.3 起「不保留原文件」的东西全挪进这里。
    /// 不直接对文件调删除接口（游戏目录里的一律只 move），
    /// 每次启动 / 每次导入前统一清空，等于丢了。
    static func trashDir() -> URL {
        docDir().appendingPathComponent(".trash", isDirectory: true)
    }

    static func ensureDirs() {
        let fm = FileManager.default
        for u in [inboxDir(), sentDir(), outDir(), retiredDir(), trashDir()] {
            var isDir: ObjCBool = false
            if !fm.fileExists(atPath: u.path, isDirectory: &isDir) {
                try? fm.createDirectory(at: u, withIntermediateDirectories: true)
            }
        }
        migrateLegacy()
        adoptSentBack()
        // 上一轮丢进回收站的东西，这时候真清掉 —— 不占地方，也不会再出现
        purgeTrash()
        purgeRetired()
    }

    /// 清空一次性回收站（里面全是「用完就该没了」的副本）
    static func purgeTrash() {
        let fm = FileManager.default
        let names = (try? fm.contentsOfDirectory(atPath: trashDir().path)) ?? []
        for n in names {
            try? fm.removeItem(at: trashDir().appendingPathComponent(n))
        }
    }

    /// 老版本收纳目录也一起清 —— v16.3 起不再靠它留副本
    static func purgeRetired() {
        let fm = FileManager.default
        let names = (try? fm.contentsOfDirectory(atPath: retiredDir().path)) ?? []
        for n in names {
            try? fm.removeItem(at: retiredDir().appendingPathComponent(n))
        }
    }

    /// 丢掉一份文件 = 不保留。先挪进回收站（同卷 rename，稳），下次启动清空。
    /// 返回 true 表示这份已经不在了。
    @discardableResult
    static func discard(_ url: URL) -> Bool {
        let fm = FileManager.default
        guard fm.fileExists(atPath: url.path) else { return true }
        if !fm.fileExists(atPath: trashDir().path) {
            try? fm.createDirectory(at: trashDir(), withIntermediateDirectories: true)
        }
        let dst = uniqueURL(trashDir(), name: url.lastPathComponent)
        do {
            try fm.moveItem(at: url, to: dst)
            return true
        } catch {
            // 极端情况（跨卷）搬不动就原地抹掉，这份本来就该没了
            return (try? fm.removeItem(at: url)) != nil
        }
    }

    /// v16.2：把老版本「已导入」里的包搬回常驻库，
    /// 升级上来的人不用再往 App 里重放一次。同名的不重复搬，收进收纳目录。
    static func adoptSentBack() {
        let fm = FileManager.default
        let names = (try? fm.contentsOfDirectory(atPath: sentDir().path)) ?? []
        for n in names where !n.hasPrefix(".") {
            let from = sentDir().appendingPathComponent(n)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: from.path, isDirectory: &isDir), !isDir.boolValue else { continue }
            guard pakExts.contains(from.pathExtension.lowercased()) else { continue }

            let dest = inboxDir().appendingPathComponent(n)
            if fm.fileExists(atPath: dest.path) {
                let sameSize = size(of: dest) == size(of: from)
                if sameSize {
                    // 库里已经有一模一样的一份，这份重复的直接丢掉（不保留）
                    discard(from)
                    continue
                }
                // 库里那份才是要用的，旧的这份不留
                discard(from)
                continue
            }
            try? fm.moveItem(at: from, to: dest)
        }
    }

    /// 常驻库占多少地方
    static func libraryBytes() -> Int64 {
        listPaks(in: inboxDir(), depth: 3).reduce(Int64(0)) { $0 + $1.size }
    }

    /// v15 的目录名带圈号，升级后自动搬过来，别让用户以为包没了
    static func migrateLegacy() {
        let fm = FileManager.default
        let pairs: [(String, URL)] = [
            ("① 待导入", inboxDir()),
            ("② 已移出", outDir()),
            ("③ 已导入", sentDir())
        ]
        for (oldName, newDir) in pairs {
            let src = docDir().appendingPathComponent(oldName, isDirectory: true)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: src.path, isDirectory: &isDir), isDir.boolValue else { continue }
            let items = (try? fm.contentsOfDirectory(atPath: src.path)) ?? []
            for n in items where !n.hasPrefix(".") {
                let from = src.appendingPathComponent(n)
                var f: ObjCBool = false
                guard fm.fileExists(atPath: from.path, isDirectory: &f), !f.boolValue else { continue }
                let to = uniqueURL(newDir, name: n)
                try? fm.moveItem(at: from, to: to)
            }
        }
    }

    // MARK: - 列文件

    static func listPaks(in dir: URL, depth: Int = 2) -> [PakItem] {
        let fm = FileManager.default
        var out: [PakItem] = []
        var seen = Set<String>()

        func walk(_ url: URL, _ level: Int) {
            guard let names = try? fm.contentsOfDirectory(atPath: url.path) else { return }
            for n in names where !n.hasPrefix(".") {
                let full = url.appendingPathComponent(n)
                var isDir: ObjCBool = false
                guard fm.fileExists(atPath: full.path, isDirectory: &isDir) else { continue }
                if isDir.boolValue {
                    if level < depth { walk(full, level + 1) }
                } else if pakExts.contains(full.pathExtension.lowercased()) {
                    if seen.contains(full.path) { continue }
                    seen.insert(full.path)
                    let attrs = try? fm.attributesOfItem(atPath: full.path)
                    let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
                    out.append(PakItem(id: full.path, url: full, size: size))
                }
            }
        }

        walk(dir, 0)
        return out.sorted { $0.name < $1.name }
    }

    static func size(of url: URL) -> Int64 {
        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        return (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    static func uniqueURL(_ dir: URL, name: String) -> URL {
        let fm = FileManager.default
        var target = dir.appendingPathComponent(name)
        if !fm.fileExists(atPath: target.path) { return target }
        let base = (name as NSString).deletingPathExtension
        let ext = (name as NSString).pathExtension
        var i = 2
        while i < 999 {
            let n = ext.isEmpty ? "\(base)-\(i)" : "\(base)-\(i).\(ext)"
            target = dir.appendingPathComponent(n)
            if !fm.fileExists(atPath: target.path) { return target }
            i += 1
        }
        return dir.appendingPathComponent(UUID().uuidString + "-" + name)
    }

    static func describe(_ error: Error) -> String {
        if let b = error as? BridgeFailure { return b.message }
        let ns = error as NSError
        switch ns.code {
        case 1:  return "没权限（这台机器没给本 App 跨 App 权限）"
        case 2:  return "找不到这个文件"
        case 13: return "没权限写这个目录"
        case 17: return "目标已存在"
        case 18: return "跨卷搬不动"
        case 28: return "空间不够"
        default: break
        }
        return ns.localizedDescription
    }

    static func freeSpaceText() -> String {
        let url = docDir()
        if let v = try? url.resourceValues(forKeys: [.volumeAvailableCapacityForImportantUsageKey]),
           let bytes = v.volumeAvailableCapacityForImportantUsage {
            return Fmt.size(Int64(bytes))
        }
        return "未知"
    }
}
