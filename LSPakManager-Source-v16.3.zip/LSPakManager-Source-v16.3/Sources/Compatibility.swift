//
//  Compatibility.swift
//  全系统版本放行
//
//  v8.7 起不再做版本闸门：这条路线（容器通道）不依赖内核布局，
//  所以 iOS 15 / 16 / 17 / 18 / 26 以及以后更高的版本，全部同一条流程。
//  这里只负责把「这台机器是什么」讲清楚，不负责拦人。
//

import Foundation
import UIKit
import Darwin

struct CompatibilityResult {
    /// 永远为 true：v8.7 不拦任何系统版本
    let ok: Bool
    /// 是否属于「没实测过」的版本，仅用于提示，不拦
    let warn: Bool
    let title: String
    let reason: String
}

enum Compatibility {

    /// 放行一切版本。
    /// 以前这里按 17 / 18 / 26 分支卡版本；现在容器通道跟内核没关系，
    /// 卡版本只会把能用的机器挡在外面，所以整段拆掉。
    static func check() -> CompatibilityResult {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        let sys = "iOS \(v.majorVersion).\(v.minorVersion).\(v.patchVersion)"
        let hw = hardwareModel()

        return CompatibilityResult(
            ok: true,
            warn: false,
            title: "全版本支持",
            reason: "\(hw) · \(sys)：走容器通道，不看系统版本，不写内核。"
        )
    }

    /// 26.x / 18.x 这种短写法，界面和诊断里用
    static func shortSystem() -> String {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        return "iOS \(v.majorVersion).\(v.minorVersion).\(v.patchVersion)"
    }

    /// 硬件标识，比如 iPhone15,3 / iPad13,8
    static func hardwareModel() -> String {
        var info = utsname()
        uname(&info)
        // 先把 machine 整个拷一份，容量提前算好。
        // 不能在 &info.machine 的独占访问区间里再读 info.machine，Swift 会直接报 overlapping accesses。
        var machine = info.machine
        let capacity = MemoryLayout.size(ofValue: machine)
        let name = withUnsafePointer(to: &machine) { ptr in
            ptr.withMemoryRebound(to: CChar.self, capacity: capacity) { cstr in
                String(cString: cstr)
            }
        }
        return name.isEmpty ? "未知机型" : name
    }

    /// 给用户看的一行设备信息
    static func deviceSummary() -> String {
        "\(hardwareModel()) · \(UIDevice.current.model) · iOS \(ProcessInfo.processInfo.operatingSystemVersionString)"
    }
}
