//
//  Store.swift
//  v16.2
//
//  这一版不连 Filza 的 WebDAV、不连任何端口，App 自己把活干完：
//
//  直连模式：本 App 有跨 App 权限 → 点「导入文件」直接覆盖写进游戏 Paks
//  接力模式：没权限 → 用系统存储面板 / Filza 深链，两步搬完，全程不联网
//
//  导入 = 直接覆盖游戏里那份原文件，不备份；覆盖成功后 App 里这个副本立刻丢掉。
//  移出 = 把导进去的包从游戏里挪出来直接丢掉，既不还原原文件，也不在 App 里留第二份。
//  也就是说：导入和移出，两头都不保留原文件。
//
//  v16.3：丢文件只用 rename/move（先挪进隐藏回收站，下次启动统一清空），
//  不对游戏目录里的任何文件调删除接口。
//
//  路径记忆照旧：Paks 路径录一次就存在本地，「② 打开 Paks」直达。
//

import Foundation
import SwiftUI
import Combine
import UIKit

enum EngineMode {
    case direct
    case relay

    var title: String {
        switch self {
        case .direct: return "直连模式 · 全自动"
        case .relay:  return "接力模式 · 不联网"
        }
    }

    var hint: String {
        switch self {
        case .direct: return "本 App 有跨 App 权限，点一下就写进游戏"
        case .relay:  return "系统没给跨 App 权限，走下面那两步"
        }
    }
}

@MainActor
final class Store: ObservableObject {

    // ── 界面状态 ──
    @Published var logLines: [String] = []
    @Published var busy = false
    @Published var busyText = ""
    @Published var statusText = "正在检查权限"
    @Published var mode: EngineMode = .relay
    @Published var gamePath: String = ""

    // ── 中转站 ──
    @Published var pending: [PakItem] = []
    @Published var importedCount = 0
    @Published var clearedCount = 0     // 本轮丢掉了几个（导入后丢副本 / 移出后丢包）
    @Published var lastScanText = "还没扫"

    // ── 记录 ──
    @Published var records: [TransferRecord] = []

    // ── 接力 ──
    @Published var paksPath: String = ""          // 记住的 Paks 绝对路径
    @Published var pathNote: String = ""          // 这一行给界面显示记忆状态
    @Published var pathRemembered = false
    @Published var filzaInstalled = false
    @Published var showExport = false
    @Published var exportItems: [URL] = []

    /// 我导进游戏的那些包名 —— 移出只认这些，别人放的一概不动
    private var importedSet: Set<String> = []

    private let kGame      = "ls16.game"
    private let kPaks      = "ls16.pakspath"
    private let kImported  = "ls16.imported"
    private let kRecords   = "ls16.records"

    init() {
        LSPaths.ensureDirs()
        let d = UserDefaults.standard
        if let g = d.string(forKey: kGame), !g.isEmpty { gamePath = g }
        if let p = d.string(forKey: kPaks), !p.isEmpty {
            // 旧版本存的可能是没洗过的写法，这里顺手收拾干净再回写
            let fixed = PathMemory.complete(p).path
            paksPath = fixed
            if fixed != p { d.set(fixed, forKey: kPaks) }
        }
        if let arr = d.array(forKey: kImported) as? [String] {
            importedSet = Set(arr)
            importedCount = importedSet.count
        }
        if let data = d.data(forKey: kRecords),
           let r = try? JSONDecoder().decode([TransferRecord].self, from: data) {
            records = r
        }
        filzaInstalled = FilzaLink.installed
        refreshPathNote()
    }

    // MARK: - 日志

    func log(_ s: String) {
        logLines.append("\(Fmt.clock())  \(s)")
        if logLines.count > 200 { logLines.removeFirst(logLines.count - 200) }
    }

    func clearLog() { logLines.removeAll() }

    // MARK: - 启动

    func bootstrap() async {
        log("· 浪神搬运 v16.2 · \(Compatibility.shortSystem())")
        log("· 不连任何端口，不走 Filza 的网络服务")
        detectEngine()
        if pathRemembered {
            log("· Paks 路径已记住：\(PathMemory.short(paksPath, keep: 2))")
        } else {
            log("· 还没记住 Paks 路径，下面「② 打开 Paks」会先开 Filza 首页")
        }
        scan()
        if pending.isEmpty {
            log("· 我的包里还没有文件：点「添加文件」放进去")
        } else {
            log("✓ 我的包里有 \(pending.count) 个（\(Fmt.size(LSPaths.libraryBytes()))）· 导入后自动丢掉，不留副本")
        }
    }

    /// 判断走哪条路
    func detectEngine() {
        switch DirectBridge.locateGame() {
        case .success(let g):
            mode = .direct
            gamePath = g.paks.path
            statusText = "已找到游戏目录"
            UserDefaults.standard.set(g.paks.path, forKey: kGame)
            log("✓ 有跨 App 权限，Paks 已定位")
            // 既然已经知道路径了，就顺手记下来，以后 Filza 那边也能直达
            if paksPath != g.paks.path {
                silentRemember(g.paks.path)
                log("✓ Paks 路径已自动记住")
            }
        case .failure(let why):
            mode = .relay
            statusText = "接力模式就绪"
            log("· \(why.message)")
            log("· 走接力：系统存储面板 / Filza 深链，都不用开网络服务")
        }
    }

    // MARK: - 扫我的包

    func scan() {
        pending = LSPaths.listPaks(in: LSPaths.inboxDir(), depth: 3)
        importedCount = importedSet.count
        lastScanText = Fmt.clock()
    }

    // MARK: - 往中转站加包（文件 App / 微信 / AirDrop 都能进来）

    func addFiles(_ urls: [URL]) {
        guard !urls.isEmpty else { return }
        busy = true
        busyText = "正在存进我的包"
        let box = LSPaths.inboxDir()

        lsCopyIntoLibrary(urls, into: box) { r in
            Task { @MainActor in
                self.busy = false
                if !r.added.isEmpty {
                    self.log("✓ 存进我的包 \(r.added.count) 个 · 以后不用再放了")
                    for n in r.added {
                        self.log("· \(n)  \(Fmt.size(LSPaths.size(of: box.appendingPathComponent(n))))")
                    }
                }
                if !r.replaced.isEmpty {
                    self.log("✓ 换了新版 \(r.replaced.count) 个（旧版直接丢掉，不留）")
                    for n in r.replaced { self.log("· \(n) 已顶成新版本") }
                }
                if !r.skipped.isEmpty {
                    self.log("· 有 \(r.skipped.count) 个里面已经一模一样，没重复占地方")
                }
                for f in r.failed { self.log("✗ \(f)") }
                self.scan()
            }
        }
    }

    // MARK: - 导入

    /// 「导入文件」：我的包里的文件全部送进游戏，同名直接覆盖原文件，导完不保留副本
    func importAll() async {
        guard !busy else { return }
        detectEngine()

        switch DirectBridge.locateGame() {
        case .success(let g):
            await directImport(into: g)
        case .failure:
            relayImport()
        }
    }

    private func directImport(into g: GameLocation) async {
        let files = LSPaths.listPaks(in: LSPaths.inboxDir(), depth: 3)
        guard !files.isEmpty else {
            log("· 我的包里还没有文件，先点「添加文件」放进去")
            return
        }

        busy = true
        busyText = "正在导入"
        defer { busy = false }

        log("开始导入 \(files.count) 个包（同名直接覆盖游戏原文件）")
        for f in files.prefix(8) {
            log("· 本次带 \(f.name)  \(Fmt.size(f.size))")
        }
        if files.count > 8 { log("· 还有 \(files.count - 8) 个没列出") }
        var ok = 0
        var failed = 0

        for (i, f) in files.enumerated() {
            busyText = "导入 \(i + 1)/\(files.count)  \(f.name)"
            do {
                let size = try DirectBridge.overwrite(f.url, into: g.paks)
                ok += 1
                importedSet.insert(f.name)
                persistImported()
                // 不保留原文件：游戏里那份已经被这份覆盖掉，App 里这个副本当场丢掉
                LSPaths.discard(f.url)
                clearedCount += 1
                addRecord(name: f.name, size: size, direction: "导入",
                          remote: g.paks.appendingPathComponent(f.name).path,
                          ok: true, note: "覆盖写入 Paks · 不留副本")
                log("↑ \(f.name)  \(Fmt.size(size))  → 已覆盖进游戏，副本已丢掉")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(f.name)：\(msg)")
                addRecord(name: f.name, size: f.size, direction: "导入",
                          remote: g.paks.appendingPathComponent(f.name).path,
                          ok: false, note: msg)
            }
        }

        log("导入结束：成 \(ok) · 败 \(failed)")
        if ok > 0 {
            log("· 游戏里已经是新包；App 里没留第二份，游戏原文件也没备份（不还原）")
        }
        if ok > 0 { sweepTrash() }
        scan()
    }

    /// 没权限时：把系统存储面板叫出来，让用户自己选到 Paks 存进去
    private func relayImport() {
        let files = LSPaths.listPaks(in: LSPaths.inboxDir(), depth: 3)
        guard !files.isEmpty else {
            log("· 我的包里还没有文件，先点「添加文件」放进去")
            return
        }
        exportItems = files.map { $0.url }
        showExport = true
        log("· 弹出系统存储面板：选到游戏的 Paks 目录，同名会问你要不要替换")
        log("· 面板里找不到游戏的目录？用下面「② 打开 Paks」走 Filza")
    }

    /// 系统导出面板存完之后
    func afterExport(saved: Bool) {
        showExport = false
        if saved {
            log("✓ 已通过系统面板写出，确认一下游戏目录里是不是新的")
            for u in exportItems {
                importedSet.insert(u.lastPathComponent)
                let sz = LSPaths.size(of: u)
                addRecord(name: u.lastPathComponent, size: sz,
                          direction: "导入", remote: paksPath, ok: true,
                          note: "系统存储面板 · 不留副本")
                LSPaths.discard(u)
                clearedCount += 1
            }
            persistImported()
            log("· 副本已经丢掉，App 里不留第二份")
            sweepTrash()
        } else {
            log("· 取消了")
        }
        exportItems = []
        scan()
    }

    // MARK: - 移出

    /// 「移出导入的文件」：只把我导进去的从游戏里拿出来丢掉，不还原原文件、不留副本
    func exportImported() async {
        guard !busy else { return }
        detectEngine()

        guard case .success(let g) = DirectBridge.locateGame() else {
            log("· 没有跨 App 权限，移出只能在 Filza 里手动做：")
            log("· 点「② 打开 Paks」→ 长按我导进去的包 → 删除。原文件已经没了，不用管还原")
            return
        }

        let inGame = Set(DirectBridge.fileNames(in: g.paks))
        var targets = importedSet.intersection(inGame)

        // 名单丢了（重装 / 换机）就往记录里找
        if targets.isEmpty {
            let fromRecords = records.filter { $0.direction == "导入" && $0.ok }
                .map { ($0.remotePath as NSString).lastPathComponent }
            targets = Set(fromRecords).intersection(inGame)
        }

        guard !targets.isEmpty else {
            log("· 游戏里没有我导进去的包")
            return
        }

        busy = true
        busyText = "正在移出"
        defer { busy = false }

        var ok = 0
        var failed = 0

        for (i, name) in targets.sorted().enumerated() {
            busyText = "移出 \(i + 1)/\(targets.count)  \(name)"
            let src = g.paks.appendingPathComponent(name)
            let size = LSPaths.size(of: src)

            do {
                // 从游戏里挪出来，直接落进回收站 —— 等于丢掉。不还原、不留第二份
                _ = try DirectBridge.moveOut(src, to: LSPaths.trashDir())
                ok += 1
                clearedCount += 1
                importedSet.remove(name)
                persistImported()
                log("↓ \(name)  已从游戏移出并丢掉（原文件不还原）")
                addRecord(name: name, size: size, direction: "移出",
                          remote: src.path, ok: true,
                          note: "移出后丢掉 · 原文件不还原")
            } catch {
                failed += 1
                let msg = LSPaths.describe(error)
                log("✗ \(name)：\(msg)")
                addRecord(name: name, size: 0, direction: "移出", remote: src.path,
                          ok: false, note: msg)
            }
        }

        log("移出结束：成 \(ok) · 败 \(failed)")
        if ok > 0 { sweepTrash() }
        scan()
    }

    // MARK: - 接力：Filza 深链

    func openInboxInFilza() {
        FilzaLink.open(LSPaths.inboxDir().path) { ok in
            Task { @MainActor in
                if ok {
                    self.log("→ 已跳到 Filza 里的「我的包」，长按选中要的包 → 拷贝")
                } else {
                    self.log("✗ 没装 Filza 或它没响应这个跳转，点「复制路径」用别的文件工具开")
                }
            }
        }
    }

    /// ② 打开 Paks：先看记忆里有没有路径，没有就看直连模式探到的，再没有才开首页
    func openPaksInFilza() {
        var target = paksPath.trimmingCharacters(in: .whitespacesAndNewlines)

        if target.isEmpty {
            if case .success(let g) = DirectBridge.locateGame() {
                target = g.paks.path
                silentRemember(target)
            } else {
                target = gamePath.trimmingCharacters(in: .whitespacesAndNewlines)
            }
        }

        guard !target.isEmpty else {
            if FilzaLink.openHome() {
                log("→ 已打开 Filza，点你收藏的 PAKS 进去，长按空白 → 粘贴")
                log("· 想以后一键直达：在 Filza 里进到 Paks，复制上面那行路径，回来点「记住」")
            } else {
                log("✗ 没装 Filza 或它没响应这个跳转")
            }
            return
        }

        FilzaLink.open(target) { ok in
            Task { @MainActor in
                if ok {
                    self.log("→ 已跳到 Paks，长按空白 → 粘贴")
                } else {
                    self.log("✗ 记忆里的路径 Filza 打不开，改成打开首页")
                    self.log("· 路径可能变了（重装游戏 / 换机），重新复制一次 Paks 路径再点「记住」")
                }
            }
        }
    }

    func copyInboxPath() {
        FilzaLink.copyPath(LSPaths.inboxDir().path)
        log("· 我的包路径已复制：\(LSPaths.inboxDir().path)")
    }

    func copyPaksPath() {
        let p = paksPath.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !p.isEmpty else {
            log("· 还没记住路径，先把 Paks 路径粘进上面那个框再点「记住」")
            return
        }
        FilzaLink.copyPath(p)
        log("· Paks 路径已复制")
    }

    // MARK: - 路径记忆

    /// 「记住」按钮：输入框有内容就用输入框，空着就自己读剪贴板
    @discardableResult
    func rememberPaksPath(_ raw: String) -> Bool {
        var input = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        var fromClipboard = false

        if input.isEmpty {
            if let c = PathMemory.fromClipboard() {
                input = c
                fromClipboard = true
            }
        }

        guard !input.isEmpty else {
            log("· 输入框是空的，剪贴板里也没找到路径")
            log("· 去 Filza 里进到 Paks，点一下路径栏 → 拷贝，再回来点「记住」")
            return false
        }

        let fixed = PathMemory.complete(input)
        guard !fixed.path.isEmpty else {
            log("· 这个不像路径：\(input)")
            return false
        }

        paksPath = fixed.path
        UserDefaults.standard.set(fixed.path, forKey: kPaks)
        refreshPathNote()

        if fromClipboard { log("· 从剪贴板读到了路径") }
        if !fixed.note.isEmpty { log("· \(fixed.note)") }
        log("✓ Paks 路径已记住：\(fixed.path)")

        if PathMemory.looksLikePaks(fixed.path) {
            if PathMemory.exists(fixed.path) {
                log("✓ 这个目录现在能直接访问到")
            } else {
                log("· App 自己看不到这个目录，不影响跳转")
            }
        } else {
            log("· 这个不是以 Paks 结尾，跳过去可能不是游戏目录，确认一下")
        }
        return true
    }

    /// 旧名字留着，其他地方调用不受影响
    func setPaksPath(_ p: String) {
        _ = rememberPaksPath(p)
    }

    func clearPaksPath() {
        paksPath = ""
        UserDefaults.standard.removeObject(forKey: kPaks)
        refreshPathNote()
        log("· 路径记忆已清除，下次「② 打开 Paks」会开 Filza 首页")
    }

    /// 静默记一次（自动探到路径时用，不刷日志）
    private func silentRemember(_ p: String) {
        let fixed = PathMemory.complete(p).path
        guard !fixed.isEmpty else { return }
        paksPath = fixed
        UserDefaults.standard.set(fixed, forKey: kPaks)
        refreshPathNote()
    }

    /// 刷新界面那一行记忆状态
    func refreshPathNote() {
        if paksPath.isEmpty {
            pathRemembered = false
            pathNote = "还没记住路径 · 输入框留空点「记住」会自动读剪贴板"
        } else {
            pathRemembered = true
            pathNote = "✓ 已记住 " + PathMemory.short(paksPath, keep: 3)
            if !PathMemory.looksLikePaks(paksPath) {
                pathNote = "✓ 已记住 " + PathMemory.short(paksPath, keep: 3) + "（看着不像 Paks）"
            }
        }
    }

    // MARK: - 从拖进来的文件里挑

    func shareToFilza() {
        let files = LSPaths.listPaks(in: LSPaths.inboxDir(), depth: 3)
        guard !files.isEmpty else {
            log("· 待导入里没有包")
            return
        }
        let sheet = UIActivityViewController(activityItems: files.map { $0.url },
                                             applicationActivities: nil)
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else {
            log("· 打不开分享面板")
            return
        }
        var top = root
        while let p = top.presentedViewController { top = p }
        if let pop = sheet.popoverPresentationController {
            pop.sourceView = top.view
            pop.sourceRect = CGRect(x: top.view.bounds.midX, y: top.view.bounds.midY,
                                    width: 1, height: 1)
        }
        top.present(sheet, animated: true, completion: nil)
        log("· 选 Filza 就能把包递过去")
    }

    // MARK: - 常驻库管理

    /// 清空我的包：只删 App 自己存的这一份，游戏里的包和游戏原文件一个都不动。
    /// 换整套包、或者想腾空间时用；平时不用管，包会一直留在这。
    func clearLibrary() {
        let fm = FileManager.default
        let box = LSPaths.inboxDir()
        let names = (try? fm.contentsOfDirectory(atPath: box.path)) ?? []
        var removed = 0
        for name in names where !name.hasPrefix(".") {
            let u = box.appendingPathComponent(name)
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: u.path, isDirectory: &isDir), !isDir.boolValue else { continue }
            if (try? fm.removeItem(at: u)) != nil { removed += 1 }
        }
        log("· 我的包已清空 \(removed) 个（只清 App 里这份，游戏里的没动）")
        log("· 想再导入就点「添加文件」重新放")
        scan()
    }

    // MARK: - 内部小工具

    /// 把这一轮丢掉的东西在后台真清掉，别占着几百兆空间等下次启动
    private func sweepTrash() {
        DispatchQueue.global(qos: .utility).async {
            LSPaths.purgeTrash()
        }
    }

    private func persistImported() {
        importedCount = importedSet.count
        if importedSet.count > 800 {
            importedSet = Set(Array(importedSet).suffix(800))
        }
        UserDefaults.standard.set(Array(importedSet), forKey: kImported)
    }

    func resetImported() {
        importedSet.removeAll()
        importedCount = 0
        UserDefaults.standard.removeObject(forKey: kImported)
        log("· 导入名单已清空，我的包里的文件会被当成新文件")
        scan()
    }

    private func addRecord(name: String, size: Int64, direction: String,
                           remote: String, ok: Bool, note: String = "") {
        records.append(TransferRecord(name: name, direction: direction, remotePath: remote,
                                      size: size, time: Fmt.shortDate(), ok: ok, note: note))
        if records.count > 300 { records.removeFirst(records.count - 300) }
        if let data = try? JSONEncoder().encode(records) {
            UserDefaults.standard.set(data, forKey: kRecords)
        }
    }

    func clearRecords() {
        records.removeAll()
        UserDefaults.standard.removeObject(forKey: kRecords)
    }

    // MARK: - 自检

    func diagnose() {
        log("── 自检 ──")
        log("系统 \(Compatibility.shortSystem()) · \(Compatibility.hardwareModel())")
        log("模式 \(mode.title)")
        for l in DirectBridge.probeReport() { log("  \(l)") }
        log("常驻库 \(LSPaths.inboxDir().path)")
        log("我的包 \(pending.count) 个 · \(Fmt.size(LSPaths.libraryBytes()))（导入后自动丢掉）")
        log("本轮丢掉 \(clearedCount) 个 · 导入名单 \(importedSet.count) 个")
        log("Filza 跳转 \(filzaInstalled ? "可用" : "不可用")")
        log("剩余空间 \(LSPaths.freeSpaceText())")
        log("路径记忆 \(pathRemembered ? "已记住" : "未记住")")
        if !paksPath.isEmpty {
            log("Paks 路径 \(paksPath)")
            log("  像 Paks \(PathMemory.looksLikePaks(paksPath) ? "是" : "不是") · 本进程能看到 \(PathMemory.exists(paksPath) ? "是" : "否")")
        }
        scan()
    }
}

// MARK: - 后台复制（不占主线程，大包也不卡界面）

/// 添加文件的结果，分开报：新存进来 / 换了新版 / 库里已有一模一样 / 失败
private struct LibraryCopyResult {
    var added: [String] = []
    var replaced: [String] = []
    var skipped: [String] = []
    var failed: [String] = []
}

/// 把用户选的文件存进常驻库。
/// 同名：大小和修改时间都一样 → 当成同一个包，跳过，不重复占地方；
///       不一样 → 当成换新版，旧版先 move 进隐藏收纳（不用删除接口），新文件顶上。
private func lsCopyIntoLibrary(_ urls: [URL], into box: URL,
                               done: @escaping (LibraryCopyResult) -> Void) {
    DispatchQueue.global(qos: .userInitiated).async {
        let fm = FileManager.default
        var r = LibraryCopyResult()

        func stamp(_ url: URL) -> Date {
            let attrs = try? fm.attributesOfItem(atPath: url.path)
            return (attrs?[.modificationDate] as? Date) ?? .distantPast
        }

        for u in urls {
            let scoped = u.startAccessingSecurityScopedResource()
            let name = u.lastPathComponent
            let dst = box.appendingPathComponent(name)

            if fm.fileExists(atPath: dst.path) {
                let sameSize = LSPaths.size(of: dst) == LSPaths.size(of: u)
                let notNewer = stamp(u) <= stamp(dst)
                if sameSize && notNewer {
                    r.skipped.append(name)
                    if scoped { u.stopAccessingSecurityScopedResource() }
                    continue
                }

                // 换新版：先复制成同目录临时名（跨卷也稳），旧版 move 进收纳，临时名再顶上
                let tmp = box.appendingPathComponent(".incoming-" + UUID().uuidString)
                do {
                    try fm.copyItem(at: u, to: tmp)
                    LSPaths.discard(dst)          // 旧版不保留
                    try fm.moveItem(at: tmp, to: dst)
                    r.replaced.append(name)
                } catch {
                    LSPaths.discard(tmp)          // 半截文件不保留
                    r.failed.append("\(name)：\(LSPaths.describe(error))")
                }
                if scoped { u.stopAccessingSecurityScopedResource() }
                continue
            }

            do {
                try fm.copyItem(at: u, to: dst)
                r.added.append(name)
            } catch {
                r.failed.append("\(name)：\(LSPaths.describe(error))")
            }
            if scoped { u.stopAccessingSecurityScopedResource() }
        }

        DispatchQueue.main.async { done(r) }
    }
}
