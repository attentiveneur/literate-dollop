//
//  DirectBridge.swift
//  v16.0
//
//  v15 是让 Filza 通过 WebDAV 帮忙搬文件。这一版把那条路整个砍掉。
//
//  现在 App 自己动手：
//  1) 能读别的 App 容器（巨魔签 / 带跨容器权限签名）→ 直接读写游戏 Paks，全自动
//  2) 读不到 → 交给上层走接力（系统导出面板 / Filza 深链），完全不碰网络服务
//
//  全程只用 copy + rename，不调用任何删除接口去抹游戏文件。
//  v16.3：导入覆盖完就丢掉 App 里的副本，移出后直接丢，两头都不保留原文件。
//

import Foundation
import Darwin

/// 失败原因（必须符合 Error，不能拿字符串直接当 failure）
struct BridgeFailure: Error {
    let message: String
}

/// 找到的游戏目录
struct GameLocation {
    let paks: URL
    let container: URL
    let tag: String
}

enum DirectBridge {

    // MARK: - 常量

    static let containersRoot: String = "/private/var/mobile/Containers/Data/Application"
    static let containersRootAlt: String = "/var/mobile/Containers/Data/Application"

    /// 游戏资源包目录的几种可能位置，按命中率排
    static let paksRelative: [String] = [
        "Documents/ShadowTrackerExtra/Saved/Paks",
        "Library/Caches/ShadowTrackerExtra/Saved/Paks",
        "Documents/ShadowTrackerExtra/Saved/Paks/Android"
    ]

    static var fm: FileManager { FileManager.default }

    // MARK: - 环境

    static func rootDir() -> URL {
        var isDir: ObjCBool = false
        if fm.fileExists(atPath: containersRoot, isDirectory: &isDir), isDir.boolValue {
            return URL(fileURLWithPath: containersRoot, isDirectory: true)
        }
        return URL(fileURLWithPath: containersRootAlt, isDirectory: true)
    }

    /// 能不能列别的 App 的容器 —— 这是「直连模式」的总开关
    static func canReachContainers() -> Bool {
        guard let list = try? fm.contentsOfDirectory(atPath: rootDir().path) else { return false }
        return !list.isEmpty
    }

    static func fileNames(in dir: URL) -> [String] {
        let all = (try? fm.contentsOfDirectory(atPath: dir.path)) ?? []
        return all.filter { !$0.hasPrefix(".") }
    }

    // MARK: - 找游戏目录

    static func locateGame() -> Result<GameLocation, BridgeFailure> {
        let root = rootDir()
        guard let ids = try? fm.contentsOfDirectory(atPath: root.path), !ids.isEmpty else {
            return .failure(BridgeFailure(message: "读不到 App 容器目录（这台机器没给跨 App 权限）"))
        }

        var hits: [GameLocation] = []

        for id in ids {
            let c = root.appendingPathComponent(id, isDirectory: true)
            for rel in paksRelative {
                let p = c.appendingPathComponent(rel, isDirectory: true)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: p.path, isDirectory: &isDir), isDir.boolValue {
                    hits.append(GameLocation(paks: p, container: c, tag: id))
                }
            }
        }

        if let first = hits.first { return .success(first) }

        // 兜底：有的版本会在 Saved 下面多一层，扫一遍拿不准就放弃
        for id in ids {
            let c = root.appendingPathComponent(id, isDirectory: true)
            let saved = c.appendingPathComponent("Documents/ShadowTrackerExtra/Saved", isDirectory: true)
            guard let subs = try? fm.contentsOfDirectory(atPath: saved.path) else { continue }
            for s in subs where s.lowercased() == "paks" {
                let p = saved.appendingPathComponent(s, isDirectory: true)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: p.path, isDirectory: &isDir), isDir.boolValue {
                    return .success(GameLocation(paks: p, container: c, tag: id))
                }
            }
        }

        return .failure(BridgeFailure(message: "有跨 App 权限，但没翻到 ShadowTrackerExtra/Saved/Paks"))
    }

    // MARK: - 底层：rename 替换（原子覆盖，不调用 unlink）

    /// 用 POSIX rename 把 src 顶到 dst 上。
    /// rename 在目标已存在时是同目录内的原子替换，内核层直接把旧 inode 换掉，
    /// 我们一个删除接口都不调，也不留备份文件。
    static func renameOver(_ src: URL, to dst: URL) throws {
        let rc: Int32 = src.withUnsafeFileSystemRepresentation { s -> Int32 in
            dst.withUnsafeFileSystemRepresentation { d -> Int32 in
                guard let s = s, let d = d else { return Int32(EINVAL) }
                return rename(s, d)
            }
        }
        if rc != 0 {
            let code = errno
            throw BridgeFailure(message: LSPaths.describe(NSError(domain: NSPOSIXErrorDomain,
                                                                 code: Int(code),
                                                                 userInfo: nil)))
        }
    }

    // MARK: - 导入（覆盖）

    /// 把 src 覆盖写进 dir，同名直接换掉。返回写好后的大小。
    @discardableResult
    static func overwrite(_ src: URL, into dir: URL) throws -> Int64 {
        let name = src.lastPathComponent
        let dst = dir.appendingPathComponent(name)

        // 先在同一目录里落一个临时名，再 rename 顶上去 —— 中途断掉也不会毁掉游戏里那份
        let tmp = dir.appendingPathComponent(".ls_new_\(UUID().uuidString).part")
        try fm.copyItem(at: src, to: tmp)

        do {
            try renameOver(tmp, to: dst)
        } catch {
            // 临时文件是我们自己刚建的，清掉不算动用户的东西
            try? fm.removeItem(at: tmp)
            throw error
        }

        let attrs = try? fm.attributesOfItem(atPath: dst.path)
        return (attrs?[.size] as? NSNumber)?.int64Value ?? 0
    }

    // MARK: - 移出

    /// 把游戏里的包搬进 dir。中转站里已有同名就加时间戳，绝不覆盖用户已有文件。
    /// 返回落地后的 URL。
    @discardableResult
    static func moveOut(_ src: URL, to dir: URL) throws -> URL {
        let name = src.lastPathComponent
        var target = dir.appendingPathComponent(name)

        if fm.fileExists(atPath: target.path) {
            let base = (name as NSString).deletingPathExtension
            let ext = (name as NSString).pathExtension
            let stamp = Fmt.stamp()
            let n = ext.isEmpty ? "\(base)-\(stamp)" : "\(base)-\(stamp).\(ext)"
            target = dir.appendingPathComponent(n)
        }

        do {
            try renameOver(src, to: target)
        } catch {
            // 极少见（跨卷）。先复制到目标，再把游戏里那份丢掉 ——
            // v16.3 起不保留原文件，所以这里不再往收纳目录攒副本。
            try fm.copyItem(at: src, to: target)
            LSPaths.discard(src)
        }

        return target
    }

    // MARK: - 自检用

    static func probeReport() -> [String] {
        var lines: [String] = []
        let root = rootDir()
        lines.append("容器根 \(root.path)")

        guard let ids = try? fm.contentsOfDirectory(atPath: root.path) else {
            lines.append("能列容器：否（没跨 App 权限）")
            return lines
        }
        lines.append("能列容器：是（\(ids.count) 个）")

        var found = 0
        for id in ids {
            let c = root.appendingPathComponent(id, isDirectory: true)
            for rel in paksRelative {
                let p = c.appendingPathComponent(rel, isDirectory: true)
                var isDir: ObjCBool = false
                if fm.fileExists(atPath: p.path, isDirectory: &isDir), isDir.boolValue {
                    found += 1
                    lines.append("命中 \(id.prefix(8))… → \(rel)")
                }
            }
        }
        if found == 0 { lines.append("没命中 ShadowTrackerExtra/Saved/Paks") }
        return lines
    }
}
