//
//  FilzaLink.swift
//  v16.1
//
//  没有跨 App 权限时用的接力通道。
//  这里一行网络代码都没有：不连端口、不开服务、不发请求，
//  只是把 Filza 用 URL Scheme 叫到指定目录前面，剩下的拖一下粘贴就完事。
//
//  v16.1 起 open 带回调：路径打不开会自己退回 Filza 首页，并把结果告诉界面，
//  免得用户点了「② 打开 Paks」以为没反应。
//

import UIKit

enum FilzaLink {

    static var installed: Bool {
        guard let u = URL(string: "filza://") else { return false }
        return UIApplication.shared.canOpenURL(u)
    }

    /// 拼 filza://view/<绝对路径>，中文和空格自动百分号编码
    static func viewURL(_ path: String) -> URL? {
        var p = path.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !p.isEmpty else { return nil }
        if !p.hasPrefix("/") { p = "/" + p }
        var c = URLComponents()
        c.scheme = "filza"
        c.host = "view"
        c.percentEncodedPath = p.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? p
        return c.url
    }

    /// 打开 Filza 并跳到这个目录；打不开就退回首页，结果通过 done 回来
    static func open(_ path: String,
                     fallbackHome: Bool = true,
                     done: ((Bool) -> Void)? = nil) {
        guard installed, let u = viewURL(path) else {
            if fallbackHome { _ = openHome() }
            done?(false)
            return
        }
        UIApplication.shared.open(u, options: [:]) { ok in
            if !ok && fallbackHome { _ = openHome() }
            done?(ok)
        }
    }

    /// 只打开 Filza 主界面（没存路径时用，让用户点自己收藏的书签）
    @discardableResult
    static func openHome() -> Bool {
        guard installed, let u = URL(string: "filza://") else { return false }
        UIApplication.shared.open(u, options: [:], completionHandler: nil)
        return true
    }

    /// 复制成文本，粘到 Filza 的地址栏也能跳
    static func copyPath(_ path: String) {
        UIPasteboard.general.string = path
    }
}
