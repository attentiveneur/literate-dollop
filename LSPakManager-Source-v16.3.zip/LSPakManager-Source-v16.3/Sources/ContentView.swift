//
//  ContentView.swift
//  v16.3
//
//  界面：现在走哪条路 / 我的包在哪 / 导入按钮 / 移出按钮。
//  布局跟 v16.2 一模一样，只换了几行字的说法。
//  接力模式才多出一块两步搬运，直连模式下这块不显示。
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers

let colorHUD   = Color(red: 0.20, green: 0.86, blue: 0.60)
let colorAmber = Color(red: 1.00, green: 0.66, blue: 0.24)
let colorCard  = Color.white.opacity(0.055)
let colorLine  = Color.white.opacity(0.10)

struct ContentView: View {

    @EnvironmentObject private var store: Store
    @Environment(\.scenePhase) private var scenePhase

    @State private var didAppear = false
    @State private var showAdd = false
    @State private var showAdvanced = false
    @State private var pathText = ""

    var body: some View {
        ZStack {
            BackgroundLayer()

            ScrollView {
                VStack(spacing: 12) {
                    header
                    statusCard
                    transitCard
                    importButton
                    exportButton
                    if store.mode == .relay {
                        relayCard
                    }
                    logCard
                    advancedCard
                }
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 30)
            }
        }
        .preferredColorScheme(.dark)
        .fileImporter(isPresented: $showAdd,
                      allowedContentTypes: [.item],
                      allowsMultipleSelection: true) { result in
            switch result {
            case .success(let urls):
                store.addFiles(urls)
            case .failure:
                store.log("· 没选文件")
            }
        }
        .sheet(isPresented: $store.showExport) {
            ExportPicker(urls: store.exportItems) { done in
                store.afterExport(saved: done)
            }
        }
        .onAppear {
            if pathText.isEmpty { pathText = store.paksPath }
            if !didAppear {
                didAppear = true
                Task { await store.bootstrap() }
            }
        }
        .onChange(of: scenePhase) { ph in
            if ph == .active {
                store.scan()
                // 从 Filza 切回来时，输入框空着就把记住的路径填回去
                if pathText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    pathText = store.paksPath
                }
                store.refreshPathNote()
            }
        }
    }

    // MARK: - 顶

    private var header: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("浪神搬运")
                .font(.system(size: 24, weight: .heavy))
                .foregroundColor(.white)
            Text("v16.3 · 导入直接覆盖原件 · 两头都不留副本")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(colorHUD.opacity(0.85))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - 状态

    private var statusCard: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(store.mode == .direct ? colorHUD : colorAmber)
                .frame(width: 8, height: 8)
                .shadow(color: (store.mode == .direct ? colorHUD : colorAmber).opacity(0.9), radius: 6)

            VStack(alignment: .leading, spacing: 2) {
                Text(store.busy ? store.busyText : store.mode.title)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundColor(.white)
                Text(store.mode == .direct
                     ? (store.gamePath.isEmpty ? "游戏目录：还没找到" : "游戏目录：已定位")
                     : store.mode.hint)
                    .font(.system(size: 10.5))
                    .foregroundColor(.white.opacity(0.55))
                    .lineLimit(2)
            }
            Spacer()
            Button {
                store.detectEngine()
                store.scan()
                store.log("· 重新检查了一遍")
            } label: {
                Text("重查")
                    .font(.system(size: 12, weight: .bold))
                    .padding(.horizontal, 12).padding(.vertical, 7)
                    .background((store.mode == .direct ? colorHUD : colorAmber).opacity(0.16))
                    .foregroundColor(store.mode == .direct ? colorHUD : colorAmber)
                    .clipShape(Capsule())
            }
            .disabled(store.busy)
        }
        .padding(12)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    // MARK: - 中转站

    private var transitCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("我的包")
                    .font(.system(size: 11.5, weight: .bold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button {
                    showAdd = true
                } label: {
                    Text("添加文件")
                        .font(.system(size: 12, weight: .bold))
                        .padding(.horizontal, 12).padding(.vertical, 5)
                        .background(colorHUD.opacity(0.16))
                        .foregroundColor(colorHUD)
                        .clipShape(Capsule())
                }
            }

            Text("文件 App → 我的 iPhone → 浪神搬运 → 待导入")
                .font(.system(size: 11.5, design: .monospaced))
                .foregroundColor(.white.opacity(0.75))
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)

            VStack(alignment: .leading, spacing: 3) {
                Text("放进来 → 点「导入文件」直接覆盖游戏里那份 → App 里这份当场丢掉")
                    .font(.system(size: 10.5))
                    .foregroundColor(colorHUD.opacity(0.85))
                Text("换包才需要再放一次；点「移出导入的文件」→ 从游戏里拿走并丢掉，不还原")
                    .font(.system(size: 10.5))
                    .foregroundColor(colorAmber.opacity(0.85))
            }

            HStack(spacing: 8) {
                countBox("我的包", store.pending.count, colorHUD)
                countBox("已导入", store.importedCount, colorAmber)
                countBox("已清掉", store.clearedCount, .white.opacity(0.7))
            }
        }
        .padding(12)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private func countBox(_ title: String, _ n: Int, _ c: Color) -> some View {
        VStack(spacing: 1) {
            Text("\(n)")
                .font(.system(size: 16, weight: .heavy, design: .rounded))
                .foregroundColor(c)
            Text(title)
                .font(.system(size: 9.5, weight: .semibold))
                .foregroundColor(.white.opacity(0.45))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.045))
        .cornerRadius(9)
    }

    // MARK: - 导入

    private var importButton: some View {
        Button {
            Task { await store.importAll() }
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("导入文件")
                        .font(.system(size: 19, weight: .heavy))
                        .foregroundColor(.black)
                    Text(store.mode == .direct
                         ? "点一下导入 · 直接覆盖游戏原文件 · 导完不留副本"
                         : "点一下导入 · 叫出系统存储面板 · 导完不留副本")
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundColor(.black.opacity(0.62))
                }
                Spacer()
                Image(systemName: "arrow.up.to.line")
                    .font(.system(size: 20, weight: .heavy))
                    .foregroundColor(.black.opacity(0.7))
            }
            .padding(.horizontal, 15)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(colors: [colorHUD, colorHUD.opacity(0.78)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .cornerRadius(14)
            .shadow(color: colorHUD.opacity(store.busy ? 0 : 0.30), radius: 12, y: 4)
        }
        .disabled(store.busy)
        .opacity(store.busy ? 0.55 : 1)
    }

    // MARK: - 移出

    private var exportButton: some View {
        Button {
            Task { await store.exportImported() }
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("移出导入的文件")
                        .font(.system(size: 18, weight: .heavy))
                        .foregroundColor(.black)
                    Text("只搬我导进去的 · 移出后直接丢掉 · 原文件不还原")
                        .font(.system(size: 10.5, weight: .medium))
                        .foregroundColor(.black.opacity(0.62))
                }
                Spacer()
                Image(systemName: "arrow.down.to.line")
                    .font(.system(size: 20, weight: .heavy))
                    .foregroundColor(.black.opacity(0.7))
            }
            .padding(.horizontal, 15)
            .padding(.vertical, 14)
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(colors: [colorAmber, colorAmber.opacity(0.78)],
                               startPoint: .topLeading, endPoint: .bottomTrailing)
            )
            .cornerRadius(14)
            .shadow(color: colorAmber.opacity(store.busy ? 0 : 0.32), radius: 12, y: 4)
        }
        .disabled(store.busy)
        .opacity(store.busy ? 0.55 : 1)
    }

    // MARK: - 接力（只有没权限时才出现）

    private var relayCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("本机没给跨 App 权限，走这两步")
                .font(.system(size: 11.5, weight: .bold))
                .foregroundColor(colorAmber)

            HStack(spacing: 8) {
                relayButton("① 打开我的包") { store.openInboxInFilza() }
                relayButton("② 打开 Paks") { store.openPaksInFilza() }
            }

            HStack(spacing: 8) {
                TextField("粘 Paks 路径，空着点「记住」自动读剪贴板", text: $pathText)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.white)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .padding(8)
                    .background(Color.white.opacity(0.06))
                    .cornerRadius(8)
                    .onSubmit { rememberPath() }

                Button {
                    rememberPath()
                } label: {
                    Text("记住")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(colorAmber)
                        .cornerRadius(8)
                }
            }

            // 记忆状态：已记住显示绿色的路径尾巴，没记住显示琥珀色提示
            HStack(spacing: 5) {
                Image(systemName: store.pathRemembered ? "checkmark.circle.fill" : "circle.dashed")
                    .font(.system(size: 9.5, weight: .bold))

                Text(store.pathNote)
                    .font(.system(size: 9.5, weight: .semibold))
                    .lineLimit(1)
                    .truncationMode(.middle)

                Spacer(minLength: 0)

                if store.pathRemembered {
                    Button {
                        store.clearPaksPath()
                        pathText = ""
                    } label: {
                        Text("清除")
                            .font(.system(size: 9.5, weight: .bold))
                            .foregroundColor(.white.opacity(0.45))
                    }
                }
            }
            .foregroundColor(store.pathRemembered ? colorHUD.opacity(0.9) : colorAmber.opacity(0.85))

            HStack(spacing: 8) {
                relayButton("发送给 Filza") { store.shareToFilza() }
                relayButton("复制我的包路径") { store.copyInboxPath() }
            }

            Text("Filza 里长按选中文件 → 拷贝 → 点「② 打开 Paks」→ 空白处长按粘贴（同名覆盖）。搬完可以在「自检」里点「清空我的包」把 App 里这份也丢掉")
                .font(.system(size: 10))
                .foregroundColor(.white.opacity(0.45))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(12)
        .background(colorAmber.opacity(0.06))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorAmber.opacity(0.28), lineWidth: 1))
        .cornerRadius(12)
    }

    /// 「记住」按钮：把输入框内容（空则读剪贴板）洗一遍存下来
    private func rememberPath() {
        if store.rememberPaksPath(pathText) {
            pathText = store.paksPath
        }
    }

    private func relayButton(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11.5, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 9)
                .background(Color.white.opacity(0.07))
                .foregroundColor(.white.opacity(0.88))
                .cornerRadius(9)
        }
        .disabled(store.busy)
    }

    // MARK: - 日志

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("运行记录")
                    .font(.system(size: 11.5, weight: .bold))
                    .foregroundColor(.white.opacity(0.55))
                Spacer()
                Button {
                    store.clearLog()
                } label: {
                    Text("清空")
                        .font(.system(size: 10.5, weight: .semibold))
                        .foregroundColor(.white.opacity(0.4))
                }
            }

            if store.logLines.isEmpty {
                Text("等一下，正在检查权限…")
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundColor(.white.opacity(0.3))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.vertical, 6)
            } else {
                VStack(alignment: .leading, spacing: 3) {
                    ForEach(logRows) { row in
                        Text(row.text)
                            .font(.system(size: 10, design: .monospaced))
                            .foregroundColor(lineColor(row.text))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
        .padding(11)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private var logRows: [LogRow] {
        var out: [LogRow] = []
        var i = 0
        for t in store.logLines.suffix(60) {
            out.append(LogRow(id: i, text: t))
            i += 1
        }
        return out
    }

    private func lineColor(_ s: String) -> Color {
        if s.contains("✓") { return colorHUD }
        if s.contains("✗") { return Color(red: 1, green: 0.45, blue: 0.4) }
        if s.contains("↑") { return colorHUD }
        if s.contains("↓") { return colorAmber }
        return Color.white.opacity(0.62)
    }

    // MARK: - 高级

    private var advancedCard: some View {
        VStack(spacing: 8) {
            Button {
                withAnimation(.easeInOut(duration: 0.16)) { showAdvanced.toggle() }
            } label: {
                HStack {
                    Text("高级")
                        .font(.system(size: 11.5, weight: .bold))
                        .foregroundColor(.white.opacity(0.5))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white.opacity(0.35))
                }
            }

            if showAdvanced {
                HStack(spacing: 8) {
                    smallButton("自检") { store.diagnose() }
                    smallButton("刷新") { store.scan() }
                    smallButton("清空导入名单") { store.resetImported() }
                }
                HStack(spacing: 8) {
                    smallButton("复制路径") { store.copyPaksPath() }
                    smallButton("清除路径") { store.clearPaksPath() }
                    smallButton("清除记录") { store.clearRecords() }
                }
                HStack(spacing: 8) {
                    smallButton("清空我的包") { store.clearLibrary() }
                }
                Text("导入 = 直接覆盖游戏原文件，覆盖成功后 App 里这份立刻丢掉；移出 = 从游戏里拿走并丢掉，不还原原文件。两个动作都不留备份。「清空我的包」只清 App 里还没导入的那几份，游戏里的文件一个都不动。")
                    .font(.system(size: 10))
                    .foregroundColor(.white.opacity(0.35))
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.top, 2)
            }
        }
        .padding(11)
        .background(colorCard)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(colorLine, lineWidth: 1))
        .cornerRadius(12)
    }

    private func smallButton(_ title: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 11.5, weight: .bold))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
                .background(Color.white.opacity(0.07))
                .foregroundColor(.white.opacity(0.85))
                .cornerRadius(8)
        }
        .disabled(store.busy)
    }
}

struct LogRow: Identifiable {
    let id: Int
    let text: String
}

// MARK: - 系统存储面板（把包导出到用户自己选的目录）

struct ExportPicker: UIViewControllerRepresentable {
    let urls: [URL]
    var onDone: (Bool) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let vc = UIDocumentPickerViewController(forExporting: urls, asCopy: true)
        vc.delegate = context.coordinator
        vc.allowsMultipleSelection = false
        return vc
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coord {
        Coord(onDone: onDone)
    }

    final class Coord: NSObject, UIDocumentPickerDelegate {
        let onDone: (Bool) -> Void

        init(onDone: @escaping (Bool) -> Void) {
            self.onDone = onDone
        }

        func documentPicker(_ controller: UIDocumentPickerViewController,
                            didPickDocumentsAt urls: [URL]) {
            let cb = onDone
            DispatchQueue.main.async { cb(true) }
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            let cb = onDone
            DispatchQueue.main.async { cb(false) }
        }
    }
}
