//
//  PathMemory.swift
//  v16.1
//
//  路径记忆：Paks 的绝对路径只录一次，之后「② 打开 Paks」一步直达，不用再点收藏。
//
//  实际用起来，用户从 Filza 复制出来的东西往往不是干净的绝对路径：
//    · 文件 App 分享出来的是 file:///var/mobile/... 这种 URL
//    · 中文目录名带成 %E5%BE%85%E5%AF%BC%E5%85%A5
//    · 有时带 /private 前缀，有时没有
//    · 只粘到 .../Application/<UUID> 或者 .../<UUID>/Documents 那一层
//  这里统一洗干净，能补全的就补到 .../ShadowTrackerExtra/Saved/Paks。
//

import Foundation
import UIKit

enum PathMemory {

    // MARK: - 洗

    /// 把各种写法收拾成干净的绝对路径（不做补全）
    static func clean(_ raw: String) -> String {
        var s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !s.isEmpty else { return "" }

        // 零宽字符、不换行空格、全角符号 —— 从聊天窗口和网页复制常带
        s = s.replacingOccurrences(of: "\u{200B}", with: "")
        s = s.replacingOccurrences(of: "\u{FEFF}", with: "")
        s = s.replacingOccurrences(of: "\u{00A0}", with: " ")
        s = s.replacingOccurrences(of: "\u{3000}", with: " ")
        s = s.replacingOccurrences(of: "／", with: "/")

        // 多行粘贴只取第一行有内容的
        if s.contains("\n") || s.contains("\r") {
            let lines = s.split(whereSeparator: { $0 == "\n" || $0 == "\r" })
                .map(String.init)
                .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }
            if let first = lines.first { s = first }
        }

        // 文件 App / 分享面板给的是 file:// 开头的 URL
        if s.lowercased().hasPrefix("file://") {
            if let u = URL(string: s), !u.path.isEmpty {
                s = u.path
            } else {
                s = String(s.dropFirst("file://".count))
            }
        }

        // 百分号编码还原（中文目录名）
        if s.contains("%"), let decoded = s.removingPercentEncoding, !decoded.isEmpty {
            s = decoded
        }

        // /private/var 与 /var 是同一个地方，留短的
        if s.hasPrefix("/private/var/") {
            s = String(s.dropFirst("/private".count))
        }

        // 去掉两头引号和空白
        s = s.trimmingCharacters(in: CharacterSet(charactersIn: "\"'“”‘’ "))

        // 去掉尾斜杠
        while s.count > 1 && s.hasSuffix("/") { s.removeLast() }

        // 内容里夹了空格又是路径（比如 "本地 / 根 /" 这种界面文案）——只留从第一个 / 开始的部分
        if let firstSlash = s.firstIndex(of: "/"), firstSlash != s.startIndex {
            let head = String(s[s.startIndex..<firstSlash]).trimmingCharacters(in: .whitespaces)
            if head.isEmpty || head.hasSuffix(":") || head == "本地" {
                s = String(s[firstSlash...])
            }
        }

        return s
    }

    // MARK: - 补全

    /// 只粘到容器层的时候，自动补全到 Paks。第二个返回值是给日志看的说明。
    static func complete(_ raw: String) -> (path: String, note: String) {
        let s = clean(raw)
        guard !s.isEmpty else { return ("", "") }

        let low = s.lowercased()
        let comps = s.split(separator: "/").map(String.init)
        let lowerComps = comps.map { $0.lowercased() }

        // 已经到 Paks 了
        if low.hasSuffix("/paks") {
            return (s, "")
        }

        // 停在 Saved
        if low.hasSuffix("/saved") {
            return (s + "/Paks", "已补全 Saved 后面的 Paks")
        }

        // 含 ShadowTrackerExtra 但没到 Paks
        if low.contains("/shadowtrackerextra") {
            if low.hasSuffix("/documents") {
                return (s + "/Saved/Paks", "已补全 Documents 后面的 Saved/Paks")
            }
            return (s + "/Saved/Paks", "已补全 ShadowTrackerExtra 后面的 Saved/Paks")
        }

        // 停在 .../Application/<UUID>
        if let ai = lowerComps.lastIndex(of: "application") {
            let after = Array(lowerComps[(ai + 1)...])
            if after.count == 1 && !after[0].isEmpty {
                return (s + "/Documents/ShadowTrackerExtra/Saved/Paks",
                        "已补全容器后面的 Documents/ShadowTrackerExtra/Saved/Paks")
            }
            if after.count == 2 && after[1] == "documents" {
                return (s + "/ShadowTrackerExtra/Saved/Paks",
                        "已补全 Documents 后面的 ShadowTrackerExtra/Saved/Paks")
            }
        }

        // 停在 Containers/Data/Application（缺 UUID）—— 补不了，原样返回
        if low.hasSuffix("/containers/data/application") {
            return (s, "这个路径缺 App 的容器编号，补不了；要进到游戏那一层再复制")
        }

        return (s, "")
    }

    // MARK: - 剪贴板

    /// 从剪贴板里挑出像路径的那一行
    static func fromClipboard() -> String? {
        guard let raw = UIPasteboard.general.string, !raw.isEmpty else { return nil }
        let lines = raw.split(whereSeparator: { $0 == "\n" || $0 == "\r" })
            .map(String.init)
            .filter { !$0.trimmingCharacters(in: .whitespaces).isEmpty }

        for line in lines {
            let c = clean(line)
            guard c.count > 4 else { continue }
            let low = c.lowercased()
            if c.hasPrefix("/") { return c }
            if low.hasPrefix("file://") { return c }
            if low.contains("shadowtrackerextra") { return c }
            if low.contains("/containers/") { return c }
        }
        return nil
    }

    // MARK: - 判断 / 显示

    /// 能不能在这个进程里看到这个路径（看不到不代表路径错，只是权限不够）
    static func exists(_ p: String) -> Bool {
        guard !p.isEmpty else { return false }
        return FileManager.default.fileExists(atPath: p)
    }

    /// 看起来像不像 Paks 全路径
    static func looksLikePaks(_ p: String) -> Bool {
        let low = p.lowercased()
        return low.hasSuffix("/saved/paks") || low.hasSuffix("/paks")
    }

    /// 界面上显示的短路径，只留最后几段
    static func short(_ p: String, keep: Int = 3) -> String {
        guard !p.isEmpty else { return "" }
        let comps = p.split(separator: "/").map(String.init)
        if comps.count <= keep { return p }
        return "…/" + comps.suffix(keep).joined(separator: "/")
    }
}
